#!/bin/sh 

astyle --style=java src/interp/*.java
astyle --style=java src/Asl/*.java
